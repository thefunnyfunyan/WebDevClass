"use strict"

var app = require('./app');

app.listen(80, function(){console.log("listening on port 80...")});
