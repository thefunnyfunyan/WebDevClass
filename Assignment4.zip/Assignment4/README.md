This is a super basic wiki page
Authentication does not work.
The user page is secured through obscurity.... url is /user
the wiki content and chat page can use marked markup language
although it really doesn't matter the user page ban and admin buttons do actually
  change the users priviledges in the database.

Honestly I have spent soo much time on this project, I hope I don't get counted off
all 60 points for the authentication and the user page but I don't have time
to get it done.
