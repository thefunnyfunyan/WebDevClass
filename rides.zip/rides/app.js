"use strict"

var express = require('express'),
    app = new express();

module.exports = exports = app;
